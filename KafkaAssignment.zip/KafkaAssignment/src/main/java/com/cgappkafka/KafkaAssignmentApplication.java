package com.cgappkafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaAssignmentApplication.class, args);
	}

}
