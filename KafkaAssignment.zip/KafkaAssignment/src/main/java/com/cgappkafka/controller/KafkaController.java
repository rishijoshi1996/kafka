package com.cgappkafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cgappkafka.service.Producer;

@RestController
@RequestMapping(value = "/kafkauser")
public class KafkaController {

	@Autowired
	private Producer producer;
	
	@GetMapping(value = "/send")
	public String producer(@RequestParam("message") String message) {
		producer.send(message);
		return "Message produced to topicuser";
	}
}
