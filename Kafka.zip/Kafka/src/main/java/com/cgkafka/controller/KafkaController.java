package com.cgkafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cgkafka.service.Producer;

@RestController
@RequestMapping("/kafka")
public class KafkaController {

	@Autowired
	private Producer producer;
//	@Autowired
//	public KafkaController(Producer producer) {
//	this.producer = producer;
//	}
	@PostMapping(value = "/publish")
	public void sendMessageToKafkaTopic(@RequestParam("message") String message){
	producer.sendMessage(message);
	}
}
